using UnityEngine;

public class PlayerChestInteractor : MonoBehaviour
{
    [Header("Raycast Settings")]
    public float interactDistance = 3f; // расстояние для взаимодействия
    public KeyCode interactKey = KeyCode.E; // клавиша открытия сундука

    private Camera playerCamera;
    private SuperChest currentChest;

    private void Start()
    {
        playerCamera = Camera.main;
    }

    private void Update()
    {
        CheckChestRaycast();

        if (currentChest != null && Input.GetKeyDown(interactKey))
        {
            currentChest.ToggleUI();
        }
    }

    void CheckChestRaycast()
    {
        Ray ray = playerCamera.ScreenPointToRay(new Vector3(Screen.width / 2, Screen.height / 2));
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit, interactDistance))
        {
            SuperChest chest = hit.collider.GetComponent<SuperChest>();
            if (chest != null)
            {
                currentChest = chest;
                return;
            }
        }

        currentChest = null;
    }
}
