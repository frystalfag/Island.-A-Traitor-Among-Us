using UnityEngine;

public class Chest : MonoBehaviour
{
    public ChestUI chestUI; // Панелька с слотами, назначается в инспекторе
}
