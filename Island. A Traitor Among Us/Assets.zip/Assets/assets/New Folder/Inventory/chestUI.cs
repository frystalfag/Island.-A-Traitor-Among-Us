using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChestUI : MonoBehaviour
{
    [Header("UI References")]
    public CanvasGroup chestPanel;        // Панелька сундука
    public Transform slotsParent;         // Родитель для слотов (панель со слотами)
    public GameObject slotPrefab;         // Префаб одного слота (с Image + Text)

    private List<GameObject> uiSlots = new List<GameObject>();
    private Chest currentChest;

    void Start()
    {
        HideUI();
    }

    /// <summary>
    /// Привязываем UI к сундуку
    /// </summary>
    public void OpenChest(Chest chest)
    {
        currentChest = chest;
        ShowUI();
        UpdateUI();
    }

    public void CloseChest()
    {
        currentChest = null;
        HideUI();
    }

    void ShowUI()
    {
        chestPanel.alpha = 1;
        chestPanel.interactable = true;
        chestPanel.blocksRaycasts = true;
    }

    void HideUI()
    {
        chestPanel.alpha = 0;
        chestPanel.interactable = false;
        chestPanel.blocksRaycasts = false;
    }

    /// <summary>
    /// Обновляет предметы в слотах UI
    /// </summary>
    public void UpdateUI()
    {
        if (currentChest == null) return;

        // Чистим старые слоты
        foreach (var slot in uiSlots)
        {
            Destroy(slot);
        }
        uiSlots.Clear();

        // Создаем новые под предметы сундука
        foreach (var item in currentChest.items)
        {
            GameObject newSlot = Instantiate(slotPrefab, slotsParent);
            uiSlots.Add(newSlot);

            // У слота должно быть Image + Text
            Image icon = newSlot.transform.Find("Icon").GetComponent<Image>();
            Text amountText = newSlot.transform.Find("Amount").GetComponent<Text>();

            if (item.icon != null) icon.sprite = item.icon;
            if (item.amount > 1) amountText.text = item.amount.ToString();
            else amountText.text = "";
        }
    }
}
