using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SuperChest : MonoBehaviour
{
    [Header("Chest Settings")]
    public int maxSlots = 5;
    public List<Item> storedItems = new List<Item>();

    [Header("UI Settings")]
    public CanvasGroup chestUIGroup; 
    public Image[] slotImages;

    private bool isOpen = false;

    private void Awake()
    {
        while (storedItems.Count < maxSlots)
            storedItems.Add(null);

        if (chestUIGroup != null)
            chestUIGroup.alpha = 0f; // скрыт изначально
    }

    private void Update()
    {
        if (isOpen) UpdateUI();
    }

    public void UpdateUI()
    {
        if (slotImages == null || slotImages.Length == 0) return;

        for (int i = 0; i < slotImages.Length; i++)
        {
            if (i < storedItems.Count && storedItems[i] != null)
            {
                slotImages[i].sprite = storedItems[i].itemIcon;
                slotImages[i].color = Color.white;
            }
            else
            {
                slotImages[i].sprite = null;
                slotImages[i].color = new Color(0, 0, 0, 0);
            }
        }
    }

    public void ToggleUI()
    {
        if (chestUIGroup == null) return;

        isOpen = !isOpen;
        chestUIGroup.alpha = isOpen ? 1f : 0f;
        chestUIGroup.blocksRaycasts = isOpen;
        chestUIGroup.interactable = isOpen;
    }
}
