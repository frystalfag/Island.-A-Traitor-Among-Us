using UnityEngine;

public class Item : MonoBehaviour
{
    public string itemName;      // Логическое имя предмета
    public Sprite itemIcon;      // Для UI
}
